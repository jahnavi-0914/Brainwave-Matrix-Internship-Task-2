// Global variables
let currentAuthMode = 'login';

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize the application
function initializeApp() {
    setupNavigation();
    setupScrollEffects();
    setupFilterButtons();
    setupVideoCategories();
    setupFormHandlers();
    setupAnimations();
}

// Navigation functionality
function setupNavigation() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    
    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });
    }
    
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Close mobile menu if open
                navMenu.classList.remove('active');
                navToggle.classList.remove('active');
            }
        });
    });
    
    // Header scroll effect
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
            header.style.boxShadow = '0 4px 30px rgba(0, 0, 0, 0.15)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
            header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        }
    });
}

// Scroll effects and animations
function setupScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll('.workout-card, .feature-card, .video-card, .class-card, .product-card, .testimonial, .stat-card');
    animateElements.forEach(el => observer.observe(el));
}

// Filter buttons functionality
function setupFilterButtons() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Get filter level
            const level = this.getAttribute('data-level');
            
            // Filter workout cards (this would be connected to actual filtering logic)
            filterWorkoutCards(level);
        });
    });
}

// Filter workout cards
function filterWorkoutCards(level) {
    const workoutCards = document.querySelectorAll('.workout-card');
    
    workoutCards.forEach(card => {
        if (level === 'all') {
            card.style.display = 'block';
            card.classList.add('fade-in-up');
        } else {
            const levelElement = card.querySelector('.level');
            if (!levelElement) return;
            
            const cardLevel = levelElement.textContent.toLowerCase();
            if (cardLevel.includes(level)) {
                card.style.display = 'block';
                card.classList.add('fade-in-up');
            } else {
                card.style.display = 'none';
                card.classList.remove('fade-in-up');
            }
        }
    });
}

// Video categories functionality
function setupVideoCategories() {
    const categoryButtons = document.querySelectorAll('.category-btn');
    
    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Get category
            const category = this.getAttribute('data-category');
            
            // Filter video cards
            filterVideoCards(category);
        });
    });
    
    // Play button functionality
    const playButtons = document.querySelectorAll('.play-btn');
    playButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Add ripple effect
            this.style.transform = 'translate(-50%, -50%) scale(1.2)';
            setTimeout(() => {
                this.style.transform = 'translate(-50%, -50%) scale(1)';
            }, 200);
            
            // Here you would implement video playing logic
            console.log('Playing video...');
        });
    });
}

// Filter video cards
function filterVideoCards(category) {
    const videoCards = document.querySelectorAll('.video-card');
    
    videoCards.forEach(card => {
        card.style.display = 'block';
        card.classList.add('fade-in-up');
    });
}

// Form handlers
function setupFormHandlers() {
    const authForm = document.getElementById('authForm');
    
    if (authForm) {
        authForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleAuthSubmit();
        });
    }
    
    // Newsletter form
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleNewsletterSubmit();
        });
    }
}

// Handle authentication form submission
function handleAuthSubmit() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const fullName = document.getElementById('fullName') ? document.getElementById('fullName').value : '';
    
    // Basic validation
    if (!email || !password) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    if (currentAuthMode === 'register' && !fullName) {
        showNotification('Please enter your full name', 'error');
        return;
    }
    
    // Simulate API call
    showLoadingState(true);
    
    setTimeout(() => {
        showLoadingState(false);
        
        if (currentAuthMode === 'login') {
            showNotification(`Welcome back to your fitness journey, ${email.split('@')[0]}!`, 'success');
        } else {
            showNotification(`Account created successfully! Welcome ${fullName || email.split('@')[0]} to your fitness journey with FitLife Pro!`, 'success');
        }
        
        closeAuthModal();
        
        // Here you would implement actual authentication logic
        console.log('Auth submitted:', { email, password, fullName, mode: currentAuthMode });
    }, 2000);
}

// Handle newsletter submission
function handleNewsletterSubmit() {
    const emailInput = document.querySelector('.newsletter-form input');
    const email = emailInput.value;
    
    if (!email) {
        showNotification('Please enter your email address', 'error');
        return;
    }
    
    // Simulate API call
    setTimeout(() => {
        showNotification('Thank you for subscribing to our newsletter!', 'success');
        emailInput.value = '';
    }, 1000);
}

// Show loading state
function showLoadingState(isLoading) {
    const submitBtn = document.getElementById('authSubmit');
    
    if (isLoading) {
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        submitBtn.disabled = true;
    } else {
        submitBtn.innerHTML = currentAuthMode === 'login' ? 'Sign In' : 'Create Account';
        submitBtn.disabled = false;
    }
}

// Setup animations
function setupAnimations() {
    const statNumbers = document.querySelectorAll('.stat-number, .stat-value');
    
    const animateCounter = (element) => {
        const target = element.textContent.trim();
        const numericValue = parseInt(target.replace(/[^\d]/g, ''));
        
        if (numericValue && numericValue > 0) {
            let current = 0;
            const increment = Math.max(1, numericValue / 50);
            const timer = setInterval(() => {
                current += increment;
                if (current >= numericValue) {
                    element.textContent = target;
                    clearInterval(timer);
                } else {
                    const suffix = target.replace(/[\d]/g, '');
                    element.textContent = Math.floor(current) + suffix;
                }
            }, 50);
        }
    };
    
    // Intersection observer for counter animation
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                counterObserver.unobserve(entry.target);
            }
        });
    });
    
    statNumbers.forEach(stat => counterObserver.observe(stat));
}

// Modal functions
function openAuthModal(mode = 'login') {
    const modal = document.getElementById('authModal');
    currentAuthMode = mode;
    
    switchAuth(mode);
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeAuthModal() {
    const modal = document.getElementById('authModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
    
    // Reset form
    const form = document.getElementById('authForm');
    if (form) {
        form.reset();
    }
}

function switchAuth(mode) {
    currentAuthMode = mode;
    
    const loginToggle = document.getElementById('loginToggle');
    const registerToggle = document.getElementById('registerToggle');
    const nameGroup = document.getElementById('nameGroup');
    const authSubmit = document.getElementById('authSubmit');
    const forgotPassword = document.getElementById('forgotPassword');
    const modalTitle = document.getElementById('modalTitle');
    
    if (mode === 'login') {
        loginToggle.classList.add('active');
        registerToggle.classList.remove('active');
        nameGroup.style.display = 'none';
        authSubmit.textContent = 'Sign In';
        forgotPassword.style.display = 'block';
        modalTitle.textContent = 'Welcome Back';
    } else {
        loginToggle.classList.remove('active');
        registerToggle.classList.add('active');
        nameGroup.style.display = 'block';
        authSubmit.textContent = 'Create Account';
        forgotPassword.style.display = 'none';
        modalTitle.textContent = 'Join the FitLife Community';
    }
}

// Demo functions
function playDemo() {
    showNotification('Demo video would play here!', 'info');
}

// Notification system
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
    `;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'check-circle';
        case 'error': return 'exclamation-circle';
        case 'warning': return 'exclamation-triangle';
        default: return 'info-circle';
    }
}

function getNotificationColor(type) {
    switch (type) {
        case 'success': return 'linear-gradient(135deg, #10B981, #22C55E)';
        case 'error': return 'linear-gradient(135deg, #EF4444, #DC2626)';
        case 'warning': return 'linear-gradient(135deg, #F59E0B, #D97706)';
        default: return 'linear-gradient(135deg, #0EA5E9, #3B82F6)';
    }
}

// Add notification animations to CSS
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 4px;
        transition: background 0.2s ease;
    }
    
    .notification-close:hover {
        background: rgba(255, 255, 255, 0.2);
    }
`;
document.head.appendChild(notificationStyles);

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('authModal');
    if (e.target === modal) {
        closeAuthModal();
    }
});

// Keyboard navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeAuthModal();
    }
});

// Wishlist functionality
document.addEventListener('click', function(e) {
    if (e.target.closest('.wishlist-btn')) {
        const btn = e.target.closest('.wishlist-btn');
        const icon = btn.querySelector('i');
        
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            btn.style.color = '#EF4444';
            showNotification('Added to wishlist!', 'success');
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            btn.style.color = '';
            showNotification('Removed from wishlist', 'info');
        }
    }
});

// Add to cart functionality
document.addEventListener('click', function(e) {
    if (e.target.textContent.trim() === 'Add to Cart') {
        e.target.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
        
        setTimeout(() => {
            e.target.innerHTML = 'Add to Cart';
            showNotification('Product added to cart!', 'success');
        }, 1000);
    }
});

// Book class functionality
document.addEventListener('click', function(e) {
    if (e.target.textContent.trim() === 'Book Class') {
        e.target.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Booking...';
        
        setTimeout(() => {
            e.target.innerHTML = 'Booked!';
            e.target.style.background = 'linear-gradient(135deg, #22C55E, #16A34A)';
            showNotification('Class booked successfully!', 'success');
            
            setTimeout(() => {
                e.target.innerHTML = 'Book Class';
                e.target.style.background = '';
            }, 3000);
        }, 1500);
    }
});

// Parallax effect for hero section
window.addEventListener('scroll', function() {
    const scrolled = window.pageYOffset;
    const heroBackground = document.querySelector('.hero-background');
    
    if (heroBackground) {
        heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// Lazy loading for images (if you add real images later)
function setupLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading
setupLazyLoading();

// Performance optimization: Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debouncing to scroll events
const debouncedScrollHandler = debounce(function() {
    // Scroll-based animations and effects
}, 10);

window.addEventListener('scroll', debouncedScrollHandler);

console.log('FitLife Pro website loaded successfully! 🏋️‍♂️💪');